
const { Router } = require("express");
const conn = require("../db/conection");

const router = Router();

// LOGIN
router.post("/auth", async (req, res) => {
    try {
        const { telefone, senha } = req.body;

        if (!telefone || !senha) {
            return res.status(400).json({
                authenticated: false,
                mensagem: "Telefone e senha são obrigatórios."
            });
        }

        const sql = `
            SELECT id, apelido, telefone
            FROM utilizadores
            WHERE telefone = ? AND senha = ?
        `;

        const [usuarios] = await conn.query(sql, [telefone, senha]);

        if (usuarios.length === 0) {
            return res.status(401).json({
                authenticated: false,
                mensagem: "Telefone ou senha incorretos."
            });
        }

        res.json({
            authenticated: true,
            mensagem: "Login realizado!",
            user: usuarios[0]
        });

    } catch (erro) {
        console.error(erro);
        res.status(500).json({ mensagem: "Erro interno no servidor." });
    }
});

// LISTAR CONTATOS
router.get("/contatos", async (req, res) => {
    try {
        const telefone = req.query.telefone;

        if (!telefone) {
            return res.status(400).json({
                mensagem: "Telefone é obrigatório."
            });
        }

        const sql = `
            SELECT id, apelido, telefone
            FROM utilizadores
            WHERE telefone <> ?
            ORDER BY apelido ASC
        `;

        const [contatos] = await conn.query(sql, [telefone]);

        res.json(contatos);

    } catch (erro) {
        console.error("Erro ao buscar contatos:", erro);
        res.status(500).json({
            mensagem: "Erro ao carregar contatos."
        });
    }
});

// BUSCAR MENSAGENS DE UMA CONVERSA ESPECÍFICA
router.get("/chat", async (req, res) => {
    try {
        const telefone = req.query.telefone;
        const contato = req.query.contato;

        if (!telefone || !contato) {
            return res.status(400).json({
                mensagem: "Telefone e contato são obrigatórios."
            });
        }

        const sql = `
            SELECT *
            FROM mensagens
            WHERE (
                telefone_remetente = ?
                AND telefone_destinatario = ?
            )
            OR (
                telefone_remetente = ?
                AND telefone_destinatario = ?
            )
            ORDER BY Id ASC
        `;

        const [mensagens] = await conn.query(sql, [
            telefone, contato,
            contato, telefone
        ]);

        res.json(mensagens);

    } catch (erro) {
        console.error("Erro ao buscar mensagens:", erro);
        res.status(500).json({
            mensagem: "Erro ao buscar mensagens."
        });
    }
});

// ENVIAR MENSAGEM
router.post("/chat", async (req, res) => {
    try {
        const { remetente, destinatario, mensagem } = req.body;

        if (!remetente || !destinatario || !mensagem?.trim()) {
            return res.status(400).json({
                mensagem: "Preencha todos os campos."
            });
        }

        const sql = `
            INSERT INTO mensagens
            (telefone_remetente, telefone_destinatario, mensagem)
            VALUES (?, ?, ?)
        `;

        await conn.query(sql, [
            remetente,
            destinatario,
            mensagem.trim()
        ]);

        res.status(201).json({
            mensagem: "Mensagem enviada com sucesso!"
        });

    } catch (erro) {
        console.error("Erro ao enviar mensagem:", erro);
        res.status(500).json({
            mensagem: "Erro ao salvar mensagem no banco."
        });
    }
});

module.exports = router;
