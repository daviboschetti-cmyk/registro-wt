
const API_URL = "http://localhost:3000";

let contatoSelecionado = null;
let intervaloMensagens = null;
let ultimaSelecao = 0;

// LOGIN
async function realizarLogin() {
    const telefone = document.getElementById("login-telefone")?.value.trim();
    const senha = document.getElementById("login-senha")?.value;

    if (!telefone || !senha) {
        alert("Preencha o telefone e a senha.");
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/auth`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ telefone, senha })
        });

        const dados = await resposta.json();

        if (resposta.ok && dados.authenticated) {
            localStorage.setItem("meuTelefone", dados.user.telefone);
            localStorage.setItem("meuApelido", dados.user.apelido || "");
            window.location.href = "chat.html";
        } else {
            alert(dados.mensagem || "Telefone ou senha incorretos.");
        }
    } catch (erro) {
        console.error(erro);
        alert("Erro ao conectar com a API.");
    }
}

// VERIFICAR LOGIN
function verificarAutenticacao() {
    const telefone = localStorage.getItem("meuTelefone");

    if (!telefone) {
        window.location.href = "index.html";
        return false;
    }

    const apelido = localStorage.getItem("meuApelido") || "";
    const conta = document.getElementById("conta-logada");

    if (conta) {
        conta.textContent = `${apelido} (${telefone})`;
    }

    return true;
}

// INICIAR CHAT
async function iniciarChat() {
    if (!verificarAutenticacao()) return;

    const campo = document.getElementById("chat-mensagem");

    if (campo && !campo.dataset.listenerAdicionado) {
        campo.addEventListener("keydown", evento => {
            if (evento.key === "Enter" && !evento.shiftKey) {
                evento.preventDefault();
                enviarMensagem();
            }
        });

        campo.dataset.listenerAdicionado = "true";
    }

    await carregarContatos();

    if (intervaloMensagens) clearInterval(intervaloMensagens);

    intervaloMensagens = setInterval(() => {
        if (contatoSelecionado) carregarMensagens();
    }, 3000);
}

// CARREGAR CONTATOS
async function carregarContatos() {
    const lista = document.getElementById("contacts-list");
    const meuTelefone = localStorage.getItem("meuTelefone");

    if (!lista) {
        console.error('Não existe o elemento id="contacts-list".');
        return;
    }

    try {
        const resposta = await fetch(
            `${API_URL}/contatos?telefone=${encodeURIComponent(meuTelefone)}`
        );

        const contatos = await resposta.json();

        if (!resposta.ok || !Array.isArray(contatos)) {
            lista.textContent = contatos.mensagem || "Erro ao carregar contatos.";
            return;
        }

        lista.innerHTML = "";

        if (contatos.length === 0) {
            lista.textContent = "Nenhum outro usuário cadastrado.";
            return;
        }

        contatos.forEach(contato => {
            const botao = document.createElement("button");
            botao.type = "button";
            botao.className = "contact-item";
            botao.dataset.telefone = contato.telefone;

            if (String(contatoSelecionado?.telefone) === String(contato.telefone)) {
                botao.classList.add("active");
            }

            const avatar = document.createElement("span");
            avatar.className = "contact-avatar";
            avatar.textContent = (contato.apelido || contato.telefone)
                .charAt(0).toUpperCase();

            const info = document.createElement("span");
            info.className = "contact-info";

            const nome = document.createElement("strong");
            nome.textContent = contato.apelido || contato.telefone;

            const telefone = document.createElement("small");
            telefone.textContent = contato.telefone;

            info.append(nome, telefone);
            botao.append(avatar, info);

            botao.addEventListener("click", () => selecionarContato(contato));

            lista.appendChild(botao);
        });

        const busca = document.getElementById("buscar-contato");
        if (busca) filtrarContatos(busca.value);

    } catch (erro) {
        console.error("Erro ao carregar contatos:", erro);
        lista.textContent = "Erro ao conectar com o servidor.";
    }
}

// BUSCAR CONTATOS
function filtrarContatos(valor) {
    const filtro = String(valor || "").toLowerCase();

    document.querySelectorAll("#contacts-list .contact-item").forEach(item => {
        item.hidden = !item.textContent.toLowerCase().includes(filtro);
    });
}

// SELECIONAR CONTATO
async function selecionarContato(contato) {
    contatoSelecionado = contato;
    const selecaoAtual = ++ultimaSelecao;

    const destino = document.getElementById("chat-destinatario");
    if (destino) destino.value = contato.telefone;

    const titulo = document.getElementById("chat-title");
    if (titulo) titulo.textContent = contato.apelido || contato.telefone;

    const subtitulo = document.getElementById("chat-subtitle");
    if (subtitulo) subtitulo.textContent = contato.telefone;

    const vazio = document.getElementById("empty-chat");
    if (vazio) vazio.hidden = true;

    await carregarMensagens(selecaoAtual);

    document.getElementById("chat-mensagem")?.focus();
}

// CARREGAR MENSAGENS DO CONTATO SELECIONADO
async function carregarMensagens(selecaoEsperada = ultimaSelecao) {
    const meuTelefone = localStorage.getItem("meuTelefone");
    const contato = contatoSelecionado;
    const container = document.getElementById("messages-box");

    if (!container || !meuTelefone || !contato) return;

    try {
        const url =
            `${API_URL}/chat?telefone=${encodeURIComponent(meuTelefone)}` +
            `&contato=${encodeURIComponent(contato.telefone)}`;

        const resposta = await fetch(url);
        const mensagens = await resposta.json();

        if (
            selecaoEsperada !== ultimaSelecao ||
            String(contatoSelecionado?.telefone) !== String(contato.telefone)
        ) return;

        if (!resposta.ok || !Array.isArray(mensagens)) {
            container.textContent = mensagens.mensagem || "Erro ao carregar mensagens.";
            return;
        }

        const estavaNoFim =
            container.scrollHeight - container.scrollTop -
            container.clientHeight < 60;

        container.innerHTML = "";

        if (mensagens.length === 0) {
            container.textContent = "Nenhuma mensagem ainda. Envie a primeira!";
            return;
        }

        mensagens.forEach(msg => {
            const minha =
                String(msg.telefone_remetente) === String(meuTelefone);

            const div = document.createElement("div");
            div.className = `msg ${minha ? "enviada" : "recebida"}`;

            const meta = document.createElement("div");
            meta.className = "msg-meta";
            meta.textContent = minha
                ? "Você"
                : (contato.apelido || contato.telefone);

            const texto = document.createElement("div");
            texto.textContent = msg.mensagem;

            div.append(meta, texto);

            if (msg.data_envio) {
                const hora = document.createElement("div");
                hora.className = "msg-hora";
                hora.textContent = new Date(msg.data_envio)
                    .toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit"
                    });
                div.appendChild(hora);
            }

            container.appendChild(div);
        });

        if (estavaNoFim) {
            container.scrollTop = container.scrollHeight;
        }

    } catch (erro) {
        console.error("Erro ao carregar mensagens:", erro);
        container.textContent = "Erro ao conectar com o servidor.";
    }
}

// ENVIAR MENSAGEM
async function enviarMensagem() {
    const campo = document.getElementById("chat-mensagem");
    const texto = campo?.value.trim();
    const meuTelefone = localStorage.getItem("meuTelefone");

    if (!contatoSelecionado) {
        alert("Selecione um contato primeiro.");
        return;
    }

    if (!texto) {
        campo?.focus();
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                remetente: meuTelefone,
                destinatario: contatoSelecionado.telefone,
                mensagem: texto
            })
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            alert(dados.mensagem || "Erro ao enviar mensagem.");
            return;
        }

        campo.value = "";
        await carregarMensagens();

        const container = document.getElementById("messages-box");
        if (container) container.scrollTop = container.scrollHeight;

        campo.focus();

    } catch (erro) {
        console.error("Erro ao enviar:", erro);
        alert("Erro ao conectar com o serviço de mensagens.");
    }
}

// SAIR DA CONTA
function sair() {
    if (intervaloMensagens) clearInterval(intervaloMensagens);

    localStorage.removeItem("meuTelefone");
    localStorage.removeItem("meuApelido");

    window.location.href = "index.html";
}

// BUSCA DOS CONTATOS
document.addEventListener("DOMContentLoaded", () => {
    const busca = document.getElementById("buscar-contato");

    if (busca) {
        busca.addEventListener("input", () => {
            filtrarContatos(busca.value);
        });
    }
});
